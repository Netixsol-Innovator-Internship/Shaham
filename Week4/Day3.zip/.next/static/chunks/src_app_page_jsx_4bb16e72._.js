(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_b4352fe1._.js",
  "static/chunks/node_modules_3ced9e72._.js",
  "static/chunks/node_modules_swiper_8b569dac._.css"
],
    source: "dynamic"
});

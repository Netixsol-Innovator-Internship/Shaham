(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_next_ff5d7e3a._.js",
  "static/chunks/src_b4352fe1._.js"
],
    source: "dynamic"
});

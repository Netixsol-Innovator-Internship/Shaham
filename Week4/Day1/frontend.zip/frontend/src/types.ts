export interface Task {
  id: string;
  title: string;
  completed: boolean;
  createdAt: string; // ISO
  updatedAt: string; // ISO
}

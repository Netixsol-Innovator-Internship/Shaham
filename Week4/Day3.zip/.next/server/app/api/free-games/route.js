var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/free-games/route.js")
R.c("server/chunks/node_modules_next_dist_be7d88e7._.js")
R.c("server/chunks/[root-of-the-server]__50066eca._.js")
R.m("[project]/.next-internal/server/app/api/free-games/route/actions.js [app-rsc] (server actions loader, ecmascript)")
R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/src/app/api/free-games/route.js [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/src/app/api/free-games/route.js [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
